<?php

namespace App\Http\Controllers;

use App\Models\CorteCaja;
use App\Models\Pago;
use App\Models\TagSale;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class CorteCajaController extends Controller
{
    protected const MONTO_CUOTA_ORDINARIA = 280;
    protected const FECHA_INICIO_TAGS_HORARIO_MEXICO = '2026-10-07';

    // ─────────────────────────────────────────
    // HOY — estado actual del corte
    // ─────────────────────────────────────────
    public function hoy()
    {
        $corte = CorteCaja::activo();

        if (!$corte) {
            return response()->json(['existe' => false]);
        }

        return response()->json([
            'existe'    => true,
            'corte'     => $corte,
            'desglose'  => $this->desgloseDelDia($corte->fecha->toDateString()),
        ]);
    }

    // ─────────────────────────────────────────
    // INTENTAR
    // ─────────────────────────────────────────
    public function intentar(Request $request)
    {
        $request->validate([
            'monto_declarado' => 'required|numeric|min:0',
        ]);

        $corte = $this->corteParaOperacion($request);

        if ($corte->estado !== 'en_proceso') {
            return response()->json(['message' => 'Este corte ya fue cerrado.'], 409);
        }

        $montoSistema = $this->montoSistemaDelDia($corte->fecha->toDateString());
        $declarado    = (float) $request->monto_declarado;
        $diferencia   = round($declarado - $montoSistema, 2);

        $intentos   = $corte->intentos ?? [];
        $numero     = count($intentos) + 1;
        $intentos[] = [
            'numero'     => $numero,
            'declarado'  => $declarado,
            'diferencia' => $diferencia,
            'at'         => now()->toIso8601String(),
        ];

        $corte->intentos = $intentos;
        $corte->save();

        return response()->json([
            'coincide'                    => $diferencia === 0.0,
            'numero_intento'              => $numero,
            'diferencia'                  => $diferencia,
            'monto_sistema'               => $montoSistema,
            'desglose'                    => $this->desgloseDelDia($corte->fecha->toDateString()),
            'puede_cerrar_con_diferencia' => $numero >= 3 && $diferencia !== 0.0,
        ]);
    }

    // ─────────────────────────────────────────
    // CERRAR
    // ─────────────────────────────────────────
    public function cerrar(Request $request)
    {
        $request->validate([
            'firma' => 'required|string|max:255',
        ]);

        $corte = $this->corteParaOperacion($request);

        if ($corte->estado !== 'en_proceso') {
            return response()->json(['message' => 'Este corte ya fue cerrado.'], 409);
        }

        $ultimoIntento = collect($corte->intentos ?? [])->last();

        if (!$ultimoIntento || (float) $ultimoIntento['diferencia'] !== 0.0
            || round((float) $ultimoIntento['declarado'] - $this->montoSistemaDelDia($corte->fecha->toDateString()), 2) !== 0.0) {
            return response()->json(['message' => 'El último intento no coincide, no se puede cerrar.'], 422);
        }

        $corte->update([
            'estado'           => 'cuadrado',
            'monto_sistema'    => $ultimoIntento['declarado'],
            'firma_capturista' => $request->firma,
            'cerrado_at'       => now(),
        ]);

        return response()->json([
            'corte'    => $corte,
            'desglose' => $this->desgloseDelDia($corte->fecha->toDateString()),
        ]);
    }

    // ─────────────────────────────────────────
    // CERRAR CON DIFERENCIA
    // ─────────────────────────────────────────
    public function cerrarConDiferencia(Request $request)
    {
        $request->validate([
            'firma' => 'required|string|max:255',
        ]);

        $corte = $this->corteParaOperacion($request);

        if ($corte->estado !== 'en_proceso') {
            return response()->json(['message' => 'Este corte ya fue cerrado.'], 409);
        }

        $intentos = $corte->intentos ?? [];

        if (count($intentos) < 3) {
            return response()->json(['message' => 'Aún no se alcanzan los 3 intentos requeridos.'], 422);
        }

        $corte->update([
            'estado'            => 'cerrado_con_diferencia',
            'monto_sistema'     => $this->montoSistemaDelDia($corte->fecha->toDateString()),
            'firma_capturista'  => $request->firma,
            'cerrado_at'        => now(),
        ]);

        return response()->json([
            'corte'    => $corte,
            'desglose' => $this->desgloseDelDia($corte->fecha->toDateString()),
        ]);
    }

        // ─────────────────────────────────────────
    // Guard — solo la cuenta admin
    // ─────────────────────────────────────────
    protected function soloAdmin(Request $request): void
    {
        abort_if(
            $request->user()->role !== 'admin',
            403,
            'Solo el administrador puede consultar los cortes.'
        );
    }

    // ─────────────────────────────────────────
    // INDEX — historial paginado (admin)
    // ─────────────────────────────────────────
    public function index(Request $request)
    {
        $this->soloAdmin($request);

        $request->validate([
            'desde'  => 'nullable|date',
            'hasta'  => 'nullable|date',
            'estado' => 'nullable|in:en_proceso,cuadrado,cerrado_con_diferencia',
            'firma'  => 'nullable|string|max:255',
        ]);

        $aperturasIndebidas = CorteCaja::where('estado', 'en_proceso')->get()
            ->filter(fn ($corte) => $corte->pendienteSoloExtraordinarios())->pluck('id');

        $cortes = CorteCaja::query()
            ->whereNotIn('id', $aperturasIndebidas)
            ->when($request->desde,  fn ($q, $v) => $q->whereDate('fecha', '>=', $v))
            ->when($request->hasta,  fn ($q, $v) => $q->whereDate('fecha', '<=', $v))
            ->when($request->estado, fn ($q, $v) => $q->where('estado', $v))
            ->when($request->firma,  fn ($q, $v) => $q->where('firma_capturista', 'like', "%{$v}%"))
            ->orderByDesc('fecha')
            ->paginate(15);

        $cortes->getCollection()->transform(fn ($c) => [
            'id'               => $c->id,
            'uuid'             => $c->uuid,
            'fecha'            => $c->fecha,
            'estado'           => $c->estado,
            'monto_sistema'    => $c->monto_sistema,
            'firma_capturista' => $c->firma_capturista,
            'cerrado_at'       => $c->cerrado_at,
            'reabierto_at'     => $c->reabierto_at,
            'intentos_count'   => count($c->intentos ?? []),
        ]);

        return response()->json($cortes);
    }

        // ─────────────────────────────────────────
    // SHOW — detalle de un corte (admin)
    // ─────────────────────────────────────────
    public function show(Request $request, CorteCaja $corte)
    {
        $this->soloAdmin($request);

        return response()->json([
            'corte'    => $corte,
            'desglose' => $this->desgloseDelDia($corte->fecha->toDateString()),
        ]);
    }

        // ─────────────────────────────────────────
    // REABRIR — desbloquea al capturista, una sola vez (admin)
    // ─────────────────────────────────────────
    public function reabrir(Request $request, CorteCaja $corte)
    {
        $this->soloAdmin($request);

        $request->validate([
            'motivo' => 'nullable|string|max:500',
        ]);

        $hoy = Carbon::now('America/Mexico_City')->toDateString();

        if ($corte->fecha->toDateString() !== $hoy) {
            return response()->json(['message' => 'Solo se puede reabrir el corte de hoy.'], 422);
        }

        if ($corte->estado === 'en_proceso') {
            return response()->json(['message' => 'Este corte no está cerrado.'], 409);
        }

        if ($corte->reabierto_at !== null) {
            return response()->json(['message' => 'Este corte ya fue reabierto una vez.'], 409);
        }

        $corte->update([
            'reabierto_at'      => now(),
            'reabierto_por'     => $request->user()->name,
            'motivo_reapertura' => $request->motivo,
        ]);

        return response()->json([
            'corte'    => $corte->fresh(),
            'desglose' => $this->desgloseDelDia($corte->fecha->toDateString()),
        ]);
    }

    // ─────────────────────────────────────────
    // Total real de efectivo del día (pagos + venta de tags)
    // ─────────────────────────────────────────
    protected function corteParaOperacion(Request $request): CorteCaja
    {
        $request->validate(['fecha' => 'nullable|date_format:Y-m-d']);
        $corte = CorteCaja::activo();
        abort_if(!$corte, 404, 'No hay un corte pendiente.');
        abort_if($request->filled('fecha') && $request->fecha !== $corte->fecha->toDateString(),
            409, 'El corte activo cambió. Actualiza la pantalla antes de continuar.');

        return $corte;
    }

    protected function ventasTagsDelDia(string $fecha): Builder
    {
        // Conservar el criterio original en los cortes históricos.
        if ($fecha < self::FECHA_INICIO_TAGS_HORARIO_MEXICO) {
            return TagSale::whereDate('sold_at', $fecha);
        }

        // sold_at se guarda en UTC; la jornada se define en horario de México.
        $inicioLocal = Carbon::parse($fecha, 'America/Mexico_City')->startOfDay();
        $inicioUtc = $inicioLocal->copy()->utc()->toDateTimeString();
        $finUtc = $inicioLocal->copy()->addDay()->utc()->toDateTimeString();

        return TagSale::where('sold_at', '>=', $inicioUtc)
            ->where('sold_at', '<', $finUtc);
    }

    protected function montoSistemaDelDia(string $fecha): float
    {
        $pagos = (float) Pago::whereDate('fecha_de_cobro', $fecha)->sum('cantidad');
        $tags  = (float) $this->ventasTagsDelDia($fecha)->sum('price');

        return round($pagos + $tags, 2);
    }

    // ─────────────────────────────────────────
    // Desglose — mismo shape que espera DesgloseFinanciero
    // ─────────────────────────────────────────
    protected function desgloseDelDia(string $fecha): array
    {
        $pagosDelDia = Pago::whereDate('fecha_de_cobro', $fecha)->get();
        $tagsDelDia  = $this->ventasTagsDelDia($fecha)->get();

        $ordinarios = $pagosDelDia->where('tipo', 'ordinario');

        $ordinario      = (float) $ordinarios->where('cantidad', self::MONTO_CUOTA_ORDINARIA)->sum('cantidad');
        $especiales     = (float) $ordinarios->where('cantidad', '!=', self::MONTO_CUOTA_ORDINARIA)->sum('cantidad');
        $extraordinario = (float) $pagosDelDia->where('tipo', 'extraordinario')->sum('cantidad');
        $ventasTags     = (float) $tagsDelDia->sum('price');

        return [
            'ordinario'      => $ordinario,
            'especiales'     => $especiales,
            'extraordinario' => $extraordinario,
            'ventasTags'     => $ventasTags,
            'tagsCount'      => $tagsDelDia->count(),
            'total'          => round($ordinario + $especiales + $extraordinario + $ventasTags, 2),
            'cantidad_pagos' => $pagosDelDia->count(),
        ];
    }

    // ─────────────────────────────────────────
// PLAZAS DEL DÍA — pagos agrupados por calle, para revisión cruzada
// contra la hoja física de conteo
// ─────────────────────────────────────────
public function plazasDelDia(Request $request)
{
    $hoy = $this->corteParaOperacion($request)->fecha->toDateString();

    $pagos = Pago::whereDate('fecha_de_cobro', $hoy)
        ->with('vecino:id,nombre,calle,numero_casa')
        ->get();

    $plazas = $pagos
        ->groupBy(fn ($pago) => $pago->vecino->calle ?? 'Sin calle')
        ->map(function ($pagosDeLaCalle, $calle) {
            return [
                'calle'          => $calle,
                'subtotal'       => round($pagosDeLaCalle->sum('cantidad'), 2),
                'cantidad_pagos' => $pagosDeLaCalle->count(),
                'pagos'          => $pagosDeLaCalle->map(fn ($p) => [
                    'id'       => $p->id,
                    'vecino'   => $p->vecino->nombre ?? 'Desconocido',
                    'numero_casa' => $p->vecino?->numero_casa,
                    'cantidad' => (float) $p->cantidad,
                    'tipo'     => $p->tipo,
                ])->values(),
            ];
        })
        ->sortBy('calle')
        ->values();

    $tagsDelDia = $this->ventasTagsDelDia($hoy)->get();

    return response()->json([
        'plazas'      => $plazas,
        'ventas_tags' => [
            'total'    => round((float) $tagsDelDia->sum('price'), 2),
            'cantidad' => $tagsDelDia->count(),
        ],
    ]);
}   
}
