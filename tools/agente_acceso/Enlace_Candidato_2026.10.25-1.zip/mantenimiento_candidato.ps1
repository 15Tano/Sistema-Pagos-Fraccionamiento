param([Parameter(Mandatory=$true)][ValidateSet('pausar','reanudar')][string]$Operacion)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'verificar_enlace.ps1')
$enPython='C:\Users\Dell\Python32\python.exe'
$enAction=if($Operacion -eq 'pausar'){'previo_pausa'}else{'previo_reanudar'}
& $enPython -B (Join-Path $PSScriptRoot 'enlace_candidato.py') $enAction
if($LASTEXITCODE -ne 0){throw 'Precondiciones no confirmadas. No se invoco el mantenimiento instalado.'}
# Delegar la operacion existente solo tras comprobar el candidato. No copia archivos ni registra tareas.
$enMaintenance='C:\SanIsidro\GestionTags\mantenimiento.ps1'
if((Get-FileHash -LiteralPath $enMaintenance -Algorithm SHA256).Hash -ne '840c500933e644fb9545c88091a287416a018b7c3e16434d634138531b97b4f4'){
    throw 'Mantenimiento instalado distinto de referencia.'
}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $enMaintenance -Operacion $Operacion
if($LASTEXITCODE -ne 0){throw 'El gestor no confirmo la operacion. Mantener revision abierta.'}
if($Operacion -eq 'reanudar'){
    Write-Output 'Se delego la reanudacion a r2. Comprobar dos ciclos nuevos; este mensaje no acredita lock adquirido ni ciclo correcto.'
}
exit 0
