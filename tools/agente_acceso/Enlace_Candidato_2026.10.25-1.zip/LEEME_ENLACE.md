# Enlace candidato de control y salud — 2026.10.25-1

Candidato separado para revisar antes de activar botones en caseta. No instala
tareas ni sustituye gestor, polling, vigilancia, SDK o ZIP de cierres publicado.
API sigue siendo autoridad de vigencias. No incluye credenciales ni DLL.

## Alcance y estado

Preparado localmente; validacion de comportamiento y panel en Dell pendientes.
No se han agregado ni ejecutado nuevas pruebas de comportamiento para esta
entrega. La comprobacion de sintaxis/manifiesto no valida botones, CIM, bloqueo,
concurrencia, DPAPI ni alertas. Primero ejecutar solo verificar y salud; no abrir
panel ni usar botones de mantenimiento hasta revisar esa salida y validar el
candidato con procesos/tareas sustituidos. No equivale a transicion permanente.

## Primera revision — PowerShell Dell, sin mantenimiento

```powershell
Expand-Archive -LiteralPath 'C:\Users\Dell\Downloads\Enlace_Candidato_2026.10.25-1.zip' -DestinationPath 'C:\SanIsidro\EnlaceCandidato_20261025'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\SanIsidro\EnlaceCandidato_20261025\verificar_enlace.ps1'
& 'C:\Users\Dell\Python32\python.exe' -B 'C:\SanIsidro\EnlaceCandidato_20261025\enlace_candidato.py' salud
```

Salud lee tareas/CIM, estado del polling/vigilancia, ensayo cerrado y SQLite
existente con mode=ro/query_only. Solo guarda informe filtrado en registros/
propio. Sin SDK, Access, DPAPI, HTTP, alertas, cambios de tareas ni consultas de
tags. La cola local sin pendientes no certifica transporte actual al servidor.
Ensayo stopped se muestra detenido_sin_verificar_cierre; leer su estado no
acredita recibos ni lock. Datos/filas/commandlines no se copian a los informes.
La vigilancia instalada permanece independiente, con sus umbrales existentes.

## Controles preparados para validacion posterior

Panel separado: panel_coordinador.ps1. Botones:

- Preparar mantenimiento: primero valida fuentes/ledger y ausencia de otros
  lectores; delega pausar al mantenimiento.ps1 instalado cuyo SHA se exige.
- Solicitar parada ensayo: confirma ruta, PID, run_id y creacion del proceso
  de ensayo_cierres.py --mantenimiento antes de escribir detener_cierres.json.
  No detiene polling, mata procesos ni anuncia cierre por escribir la peticion.
- Verificar cierre: exige stopped por limit/requested, gate sin fallo/cliente,
  ausencia de proceso y otros lectores, ninguna revision pendiente, ledger
  completo con recibos/ACK y toma/liberacion de sync.lock existente. No lo borra.
- Terminar y reanudar: exige lo anterior y mantenimiento activo antes de
  delegar reanudar al gestor r2 verificado. La reanudacion instalada aun verifica
  proceso con su contrato legacy; no certifica lock adquirido ni dos ciclos.
  Obtener estado.json y dos ciclos nuevos sigue siendo obligatorio.
- Consultar salud: evaluacion separada de vigencias, ensayo readonly y cola.

El panel no inicia el lector. Para una futura prueba SDK, se conserva el
lanzador de cierres ya validado, sin cambiarlo; requiere mantenimiento confirmado
y cierre de ZKAccess. No ejecutarlo en esta primera revision. La parada del
ensayo sigue acotada150s/propia; cerrar el panel no detiene un ensayo ajeno.
Mientras un control del panel esta en curso se impide cerrar la ventana.

Rutas fijas: ZKSync y GestionTags instalados; CierresCoordinador_20261024 para
fuentes de recibos, verificadas contra manifiesto congelado del ZIP publicado;
CoordinadorEnsayo_20261024/datos/lectura_mantenimiento para estado, ledger y cola.
No inicializa otra base ni cambia identidad. La verificacion de cierres reutiliza
adaptadores ya diagnosticados; importarlos no carga DLL ni abre el controlador.

Python sin script identificable u otra herramienta Python en C:\SanIsidro no
reconocida bloquea cierre por precaucion. CIM inaccesible y PID reutilizado
impiden confirmacion. No cerrar procesos ajenos para eludir la comprobacion.
El lock solo prueba disponibilidad en ese instante, no reserva una transicion
entre procesos externos: no abrir lectores, gestor de tags ni otro ensayo
durante la pausa/reanudacion. ZKAccess no respeta ese lock. El mutex del panel
serializa sus operaciones; no sustituye exclusion de otros programas.

## Pendientes antes de uso operativo

Validar errores, identidades, timeout, carrera con reanudacion y panel sobre
datos/procesos/tareas ficticios; comprobar comportamiento real solo despues.
Integracion dentro de los botones originales, nueva version operativa con
run_id/confirmacion de lock, emisor automatico independiente, alertas separadas,
recuperacion/retencion/reconciliacion y transicion permanente siguen pendientes.
No se ha desplegado el backend de ingesta a produccion ni creado pantalla web.
