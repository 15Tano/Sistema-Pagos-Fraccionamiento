"""Pruebas sin DLL, red, tareas ni hardware."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import lector_eventos as reader


class FakeSDK:
    def __init__(self, fail=False):
        self.fail = fail
        self.disconnected = False

    def Connect(self, connection):
        return 1

    def Disconnect(self, handle):
        self.disconnected = True

    def GetDeviceParam(self, handle, buf, size, field):
        buf.value = ('~SerialNumber=' + reader.SERIAL).encode()
        return 0

    def GetRTLog(self, handle, buf, size):
        buf.value = b'2026-10-23 12:00:00,1,5324916,1,0,0,4\r\n'
        return -3 if self.fail else 1

    def GetDeviceData(self, handle, buf, size, table, fields, condition, options):
        assert table == b'transaction' and condition == b'Cardno=5324916' and options == b''
        buf.value = b'Cardno,Pin,Verified,DoorID,EventType,InOutState,Time_second\r\n5324916,1,4,1,0,0,1\r\n'
        return 1


class ReaderTests(unittest.TestCase):
    def test_status_never_identified_as_card_event(self):
        row = reader.rt_rows(b'2026-10-23 12:00:00,0,5324916,0,255,0,200\r\n')[0]
        self.assertEqual(row['kind'], 'status')

    def test_unknown_format_rejected(self):
        with self.assertRaises(RuntimeError):
            reader.rt_rows(b'not,seven,columns')
        with self.assertRaises(RuntimeError):
            reader.history_rows(b'Cardno,Pin\r\n1,2\r\n', 2)

    def test_raw_error_kept_and_disconnected(self):
        for fail in [False, True]:
            sdk = FakeSDK(fail)
            commands = '\n'.join(json.dumps(c) for c in [
                {'command': 'connect'}, {'command': 'history', 'tag': '5324916'},
                {'command': 'rt'}, {'command': 'close'}])
            output = io.StringIO()
            with tempfile.TemporaryDirectory() as tmp, \
                 patch.object(reader, 'load_sdk', return_value=(sdk, types.SimpleNamespace(close=lambda: None), {})), \
                 patch.object(reader, 'maintenance_guard'), \
                 patch('sys.stdin', io.StringIO(commands)), patch('sys.stdout', output):
                reader.worker(Path(tmp), 'A')
                raw = (Path(tmp) / 'A_0003_GetRTLog.buffer.bin').read_bytes()
                payload = (Path(tmp) / 'A_0003_GetRTLog.payload.bin').read_bytes()
                meta = json.loads((Path(tmp) / 'A_0003_GetRTLog.json').read_text())
                self.assertEqual(len(raw), 65536)
                self.assertEqual(raw.split(b'\0', 1)[0], payload)
                self.assertTrue(sdk.disconnected)
                self.assertEqual(meta['return_code'], -3 if fail else 1)
                self.assertEqual(json.loads(output.getvalue().splitlines()[-1])['ok'], not fail)

    def test_maintenance_denied_before_connect(self):
        sdk = FakeSDK()
        with patch.object(reader, 'load_sdk', return_value=(sdk, types.SimpleNamespace(close=lambda: None), {})), \
             patch.object(reader, 'maintenance_guard', side_effect=RuntimeError('no maintenance')), \
             patch.object(sdk, 'Connect') as connect, \
             patch('sys.stdin', io.StringIO('{"command":"connect"}\n')), patch('sys.stdout', io.StringIO()):
            reader.worker(Path('.'), 'A')
            connect.assert_not_called()

    def test_history_duplicate_loss_detected(self):
        result = reader.history_comparison([{'a': '1'}, {'a': '1'}], [{'a': '1'}])
        self.assertEqual(len(result['missing_rows']), 1)

    def test_session_sdk_failure_closes_clients_and_records_error(self):
        clients = []
        class Client:
            def __init__(self, folder, name):
                self.name, self.closed = name, False
                clients.append(self)
            def call(self, command, **kwargs):
                if self.name == 'B' and command == 'connect':
                    raise RuntimeError('second connection refused')
                return {'rows': []}
            def close(self):
                self.closed = True
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(reader, 'ROOT', Path(tmp)), \
             patch.object(reader, 'load_sdk', return_value=(None, types.SimpleNamespace(close=lambda: None), {})), \
             patch.object(reader, 'maintenance_lock', contextlib.nullcontext), \
             patch.object(reader, 'Client', Client), patch('sys.stdout', io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, 'second connection'):
                reader.session(types.SimpleNamespace(tag='5324916', pluma='test', seconds=5))
            report = json.loads(next(Path(tmp).rglob('resumen.json')).read_text())
            self.assertEqual(report['status'], 'incomplete')
            self.assertIn('error', report)
            self.assertTrue(all(c.closed for c in clients))

    def test_complete_experiment_keeps_distinct_clients_and_reconnects(self):
        clients = []
        class Client:
            def __init__(self, folder, name):
                self.name, self.closed, self.calls = name, False, []
                clients.append(self)
            def call(self, command, **kwargs):
                self.calls.append(command)
                if command != 'rt':
                    return {'file': self.name, 'rows': []}
                # Baseline first, then controlled event for each first reader.
                count = self.calls.count('rt')
                payload = f'2026-10-23 12:00:0{count},1,5324916,1,0,0,4\r\n'.encode()
                rows = reader.rt_rows(payload) if count == 2 or (self.name == 'B' and count == 4) else []
                return {'file': self.name, 'rows': rows}
            def close(self):
                self.closed = True
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(reader, 'ROOT', Path(tmp)), \
             patch.object(reader, 'load_sdk', return_value=(None, types.SimpleNamespace(close=lambda: None), {})), \
             patch.object(reader, 'maintenance_lock', contextlib.nullcontext), \
             patch.object(reader, 'Client', Client), patch('builtins.input', return_value='observado'), \
             patch('sys.stdout', io.StringIO()):
            reader.session(types.SimpleNamespace(tag='5324916', pluma='test', seconds=5))
            report = json.loads(next(Path(tmp).rglob('resumen.json')).read_text())
            self.assertEqual(report['status'], 'captured_pending_review')
            self.assertEqual([r['first'] for r in report['rounds']], ['A', 'B'])
            self.assertIn('history_first_experiment', report)
            self.assertEqual([c.name for c in clients], ['A', 'B', 'C_reconexion'])
            self.assertTrue(all(c.closed for c in clients))


if __name__ == '__main__':
    unittest.main()
